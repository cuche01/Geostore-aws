/**
 * Provides...
 */
package it.geosolutions.geostore.core.model.adapter;

